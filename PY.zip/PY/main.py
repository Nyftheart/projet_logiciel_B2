import pygame
from game import Game
pygame.init()

#fps

clock = pygame.time.Clock()
FPS = 60



# generation de la fenetre

pygame.display.set_caption("test jeux")
screen = pygame.display.set_mode((1080, 720))

# backgound

background = pygame.image.load('assets/bg.jpg')

#menu

banner = pygame.image.load('assets/banner.png')
banner = pygame.transform.scale(banner, (500, 500))
banner_rect = banner.get_rect()
banner_rect.x = screen.get_width() /4

#bouton

play_button = pygame.image.load('assets/button.png')
play_button = pygame.transform.scale(play_button, (400, 150))
play_button_rect = play_button.get_rect()
play_button_rect.x = screen.get_width() /3.33 + 7
play_button_rect.y = screen.get_height() /2 + 35


option_button = pygame.image.load('assets/option.png')
option_button = pygame.transform.scale(option_button, (100, 50))
option_button_rect = option_button.get_rect()
option_button_rect.x = screen.get_width() /3.33 + 150
option_button_rect.y = screen.get_height() /2 + 185





# chargement du joueur
game = Game()

running = True

# boucle de running (tant que vrai)

while running:

    # background

    screen.blit(background, (0, -200))

    fichier = open("C:/Users/alexa/Desktop/PY/score.txt", "r")
    score = fichier.read()
    fichier.close()

    font = pygame.font.SysFont("monospace", 25)
    hi_score_text = font.render(f"HI-Score: {score}  ", 1, (0, 0, 0))
    screen.blit(hi_score_text, (20, 20))

    #verifier le comecement

    if game.is_playing:
        game.update(screen)
    else:
        screen.blit(play_button, (play_button_rect.x, play_button_rect.y))
        screen.blit(option_button, (option_button_rect.x, option_button_rect.y))
        screen.blit(banner, (banner_rect.x, 0))


    # mise a jour de l'écran
    pygame.display.flip()

    # si le joueur ferme la fenetre
    for event in pygame.event.get():
        # event fermeture
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
        #detection touche clavier
        elif event.type == pygame.KEYDOWN:
            game.pressed[event.key] = True

            #touche espace
            if event.key == pygame.K_SPACE:
                game.player.lunch_projectile()



        elif event.type == pygame.KEYUP:
            game.pressed[event.key] = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if play_button_rect.collidepoint(event.pos):
                game.start()
                game.sound_manager.play('click')
            if option_button_rect.collidepoint(event.pos):
                game.start()


    clock.tick(FPS)



